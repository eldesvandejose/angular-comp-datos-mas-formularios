import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Form05User } from '../../amf-classes/form05-user';

@Component({
  selector: 'amf-form05',
  templateUrl: './form05.component.html',
  styleUrls: ['./form05.component.css']
})
export class Form05Component implements OnInit {
  public dni: string;
  public nombre: string;
  public errorDetected: boolean;
  public recordSaved: boolean;
  public User: Form05User;

  @Output() enviarUsuario = new EventEmitter<Form05User>();

  constructor() {
    this.dni = '';
    this.nombre = '';
    this.errorDetected = false;
    this.recordSaved = false;
  }

  ngOnInit() {}
  saveRecord() {
    if (this.dni.length === 0 || this.nombre.length === 0) {
      this.errorDetected = true;
      this.recordSaved = false;
    } else {
      this.errorDetected = false;
      this.recordSaved = true;
      // Creamos un objeto de la clase Form05User
      this.User = new Form05User(this.dni, this.nombre);
      this.enviarUsuario.emit(this.User);
      //      this.enviarMatriz.emit(this.matrizDeUsuarios);

      this.dni = '';
      this.nombre = '';
    }
  }

  clearNotice() {
    this.errorDetected = false;
    this.recordSaved = false;
  }
}
