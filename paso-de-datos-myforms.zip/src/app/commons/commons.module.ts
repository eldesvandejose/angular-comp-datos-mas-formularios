import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar/navbar.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { NotFoundComponent } from './not-found/not-found.component';
import { Form05ManagerComponent } from './form05-manager/form05-manager.component';
import { MyFormsModule } from '../my-forms/my-forms.module';
import { UsersListComponent } from './users-list/users-list.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MyFormsModule
  ],
  declarations: [NavbarComponent, HeaderComponent, HomeComponent, NotFoundComponent, Form05ManagerComponent, UsersListComponent],
  exports: [NavbarComponent, HeaderComponent, HomeComponent, NotFoundComponent]
})
export class CommonsModule { }
