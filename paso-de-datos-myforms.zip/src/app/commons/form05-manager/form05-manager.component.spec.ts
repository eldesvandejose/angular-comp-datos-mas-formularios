import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Form05ManagerComponent } from './form05-manager.component';

describe('Form05ManagerComponent', () => {
  let component: Form05ManagerComponent;
  let fixture: ComponentFixture<Form05ManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Form05ManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Form05ManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
