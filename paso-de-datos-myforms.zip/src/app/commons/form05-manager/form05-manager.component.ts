import { Component, OnInit } from '@angular/core';
import { Form05User } from '../../amf-classes/form05-user';

@Component({
  selector: 'amf-form05-manager',
  templateUrl: './form05-manager.component.html',
  styleUrls: ['./form05-manager.component.css']
})
export class Form05ManagerComponent implements OnInit {

  User: Form05User;
  UsersArray: Form05User[] = [];
  registeredUsers = 0;


  constructor() { }

  ngOnInit() {}

  mostrar(evento) {
    this.User = evento;
    this.UsersArray.push (this.User);
    this.registeredUsers = this.UsersArray.length;
  }

  erase(user: Form05User) {
    const index = this.UsersArray.indexOf(user);
    this.UsersArray.splice(index, 1);
    this.registeredUsers = this.UsersArray.length;
  }
}
