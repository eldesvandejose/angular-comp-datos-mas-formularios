import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Form05User } from '../../amf-classes/form05-user';


@Component({
  selector: 'amf-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {
  @Input() registeredUsers = 0;
  @Input() UsersArray: Form05User[];

  @Output() eraseUser = new EventEmitter<Form05User>();
  constructor() {}

  ngOnInit() {}

  deleteUser(deletedUser: Form05User) {
    this.eraseUser.emit(deletedUser);
  }
}
